/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.umariana.proyecto;

/**
 *
 * @author Sistemas
 */
public class Proyecto {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
